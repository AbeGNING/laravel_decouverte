<?php
    $titre = "Bien connecté!"
?>



<?php $__env->startSection('contenu'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Accueil')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <a class="btn btn-primary" href="<?php echo e(route('livres.ajout')); ?>">Ajouter un livre</a> 
                    <a class="btn btn-success" href="">Liste des livres</a> 
                    
                </div>
            </div>
        </div>
    </div>
</div>
<br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\formation\resources\views/home.blade.php ENDPATH**/ ?>