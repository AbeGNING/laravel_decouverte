<?php
    $titre = $titreController   /// titre de ma page web
?>

  <!--- page Accueil hérite du gabarit Welcome ---->

<?php $__env->startSection('contenu'); ?>   <!--- contenu a afficher a la section (yield) "contenu" -->

<div class="container">
    <div class="row">
        <div class="col-md-12 pb-5 pt-5">
        <div class="lead">
            <b>Texte Accueil</b> <br>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolor mollitia vitae enim veritatis, numquam earum laboriosam alias corporis iusto a, accusantium aspernatur quasi quia consequatur illo aperiam perferendis quod est.
        </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\formation\resources\views/pages/contact.blade.php ENDPATH**/ ?>