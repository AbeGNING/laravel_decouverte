<?php
    $titre = $titreController   /// titre de ma page web
?>

  <!--- page Accueil hérite du gabarit Welcome ---->

<?php $__env->startSection('contenu'); ?>   <!--- contenu a afficher a la section (yield) "contenu" -->

<div class="container">
    <div class="row">
        <div class="col-md-12 pb-5 pt-5">
            
            <?php if($les_produits->count() > 0): ?>
                <div class="card">
                  <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Categorie</th>
                                <th>Prix</th>
                                <th>Origine</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $les_produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($produit->nom); ?></td>
                                <td><?php echo e($produit->categorie); ?></td>
                                <td><?php echo e($produit->prix); ?></td>
                                <td><?php echo e($produit->origine); ?></td>
                            </tr>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                   <div class="justify-content-center d-flex">
                    <?php echo e($les_produits->links()); ?>

                   </div>
                </div>
                </div>
            <?php else: ?>
                <p> Aucun produit n'a été enregistré </p>
            <?php endif; ?>
            
        </div>
        <div class="col-md-12">

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\formation\resources\views/pages/produit.blade.php ENDPATH**/ ?>